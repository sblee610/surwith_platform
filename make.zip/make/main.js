var express = require('express');
var app = express();
var fs = require('fs');
var path = require('path');
var qs = require('querystring');
var bodyParser = require('body-parser');
var sanitizeHtml = require('sanitize-html');
var compression = require('compression')
var template = require('./lib/template.js');
var menuRouter = require('./routes/menu');
 
app.use(express.static('images'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(compression());

 
app.use('/', menuRouter);

app.listen(3000);