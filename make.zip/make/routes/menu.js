var express = require('express');
var app = express();
var router = express.Router();
var path = require('path');
var fs = require('fs');
var sanitizeHtml = require('sanitize-html');
var template = require('../lib/template.js');
 
app.use(express.static('../images'));

function page(style, body){
    return `
    <head>
        <meta charset="utf-8">
        <style>
        ${template.header_style()}
        ${style}
        </style>
    </head>
    <body>
        ${template.header_body()}
        ${body}
    </body> 
        `;
}

router.get('/', function(request, response){
    response.send(page('',''));
  });

router.get('/company', function(request, response){
    response.send(page('',`<div>회사소개</div>`));
  });
router.get('/study', function(request, response){
    response.send(page(
    `
    @font-face{
      font-family:"KoPubWorldDotum";
      src:url("./font/KoPubWorld Dotum Medium.ttf") format("truetype");
  }
  .학습법{
      position: relative;
      top:104px;
      display: grid;
      max-width: 1440px;
      grid-template-columns: repeat(3, 1fr);
      grid-template-rows: auto;
      margin-left:auto;
      margin-right:auto;
      row-gap: 0px;
  }
  @media screen and (max-width:800px){
      .학습법{
          grid-template-columns: repeat(1, 1fr);
      }
  }
  #수업방식{
      grid-column: 1/-1;
      text-align: center;
      font-family: KoPubWorldDotum;
      font-style: bold;
      font-weight: 500;
      font-size: 36px;
      line-height: 46px;
      align-items: center;
      text-align: center;
      margin-bottom:39px;
  }
  .box{
      display: flex;
      flex-direction: column;
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 500;
      line-height: 46px;
      align-items: center;
      text-align: center;
  }
  .classtxt{
      font-size: 30px;
  }
  .classimage{
      width:80%;
      margin-bottom: 39px;
  }
  #classex{
      width:80%;
      font-size:24px;
  }
  .com{
      margin-top: 40px;
      grid-column: 1/-1;
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 500;
      line-height: 46px;
      align-items: center;
      text-align: center;
      font-size: 30px;
      z-index:1;
  }
  .under1{
      position:relative;
      top:-25px;
      grid-column: 1/-1;
      background: #FFD60C;
      border-radius: 50px;
      width:25%;   
      margin-left: auto;
      margin-right: auto; 
  }
  .under2{
      position:relative;
      top:-25px;
      grid-column: 1/-1;
      background: #FFD60C;
      border-radius: 50px;
      width:13%;   
      margin-left: auto;
      margin-right: auto; 
  }
  .under3{
      position:relative;
      top:-25px;
      grid-column: 1/-1;
      background: #FFD60C;
      border-radius: 50px;
      width:20%;   
      margin-left: auto;
      margin-right: auto; 
  }
  .ex{
      width:80%;
      margin-left: auto;
      margin-right: auto;
      grid-column: 1/-1;
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 500;
      line-height: 46px;
      align-items: center;
      text-align: center;
      font-size: 24px;
  }
    `,
    ` <div class="학습법">
    <span id="수업방식">수업방식</span>
    <div class="box">
        <span class="classtxt">Before class</span>
        <img src="../images/beforeclass.png" class="classimage">
        <span id="classex">수업 시간 전에 수업에서 활용할 문법, 어휘를 다룬 영상이 미리 제공됩니다.</span>
    </div>
    <div class="box">    
        <span class="classtxt">During class</span>
        <img src="../images/duringclass.png" class="classimage">
        <span id="classex">수업 시간에는 영상에서 배운 문법, 어휘를 바탕으로 원어민 선생님과 다양한 
            활동을 진행하며, 회화, 문법에서 나아가 문화적 맥락까지 함께 학습하게 됩니다. </span>
    </div>
    <div class="box">
        <span class="classtxt">After class</span>
        <img src="../images/afterclass.png" class="classimage">
        <span id="classex">수업 시간 후에 과제는 없기에 휴식을 취하시면 됩니다.
            <br><br>*선택사항:DELE 취득을 목표로 한다면, 영상, 수업을 통해 학습한 내용을 복습할 수 
            있는 DELE 기출문제가 제공됩니다.</span>
    </div>
    <span class="com">HOW AND WHY?</span>
    <span class="under1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
    <span class="ex">서윗은 영상을 활용하여 수업시간에 개념을 가르치는 시간을 최소화하고, 
        대화를 통해 개념을 실전에 적용할 수 있도록 연습 및 활용하는 시간을 최대화 합니다.
        수업시간에는 사전 영상을 통해 접했던 문법 개념과 어휘를 원어민과 함께 
        다양한 상황별 활동에 적용 및 응용해보며 체득하게 됩니다. 
        이런 과정 속에서 스페인/라틴 문화 및 라이프스타일을 자연스럽게 학습할 수 있게 됩니다.
    </span>
    <span class="com">WITH?</span>
    <span class="under2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
    <span class="ex">영어 혹은 스페인어로 소통이 가능하신 분은 원어민 선생님과, 
        소통이 어려우신 분은 한국인 선생님 및 원어민 선생님과 함께 수업을 진행합니다.
    </span>
    <span class="com">REMEMBER!</span>
    <span class="under3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
    <span class="ex">서윗은 DELE 취득을 목표로 하지 않습니다. DELE를 기본 전제로 두기 때문입니다. 
        해당 자격증 취득을 원하시는 분에 한하여 수업시간마다 배우는 문법, 회화 내용을 기반으로 한 
        DELE 시험 기출 문제를 제공해드립니다. 
    </span>
</div>`));
  });
  router.get('/class', function(request, response){
    response.send(page(`@font-face{
      font-family:"KoPubWorldDotum";
      src:url("./font/KoPubWorld Dotum Medium.ttf") format("truetype");
  }
  .커리큘럼{
    position:relative;
    top:104px;
      display: grid;
      max-width: 1440px;
      grid-template-columns: repeat(2, 1fr);
      grid-template-rows: auto;
      margin-left:auto;
      margin-right:auto;
      row-gap: 0px;
  }
  @media screen and (max-width:800px){
      .커리큘럼{
          grid-template-columns: repeat(1, 1fr);
      }
  }
  #curriculum{
      grid-column: 1/-1;
      text-align: center;
      font-family: KoPubWorldDotum;
      font-style: bold;
      font-weight: 500;
      font-size: 36px;
      line-height: 46px;
      align-items: center;
      text-align: center;
      margin-bottom:39px;
  }
  #curriculumtxt{
      grid-column: 1/2;
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 500;
      font-size: 30px;
      line-height: 46px;
      display: flex;
      align-items: center;
      text-align: center;
      color:#000000;
      margin-left:auto;
      margin-right:auto;
  }
  #curriculumtxt2{
      grid-column:2/3;
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 500;
      font-size: 30px;
      line-height: 46px;
      display: flex;
      align-items: center;
      text-align: center;
      color:#000000;
      margin-left:auto;
      margin-right:auto;
  }
  .target{
      display: flex;
  }
  .targettxt{
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 500;
      font-size: 30px;
      line-height: 46px;
      display: flex;
      align-items: center;
      text-align: center;
      color: #000000;
      background: #FFD60C;
      border-radius: 50px;
      height: 40%;
      width: 20%;
      margin-left:auto;
      margin-right:auto;
  }
  .checkv{
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 300;
      font-size: 20px;
      line-height: 31px;
      display: flex;
      align-items: center;
      color: #FE0000;
  }
  .checktxt{
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 300;
      font-size: 20px;
      line-height: 31px;
      display: flex;
      align-items: center;
      color: #000000;
  
  }
  .classimage{
      width:80%;
      margin-bottom: 39px;
  }
  
  .tt{
      display: flex;
  
  }
  
  #period{
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 500;
      font-size: 20px;
      line-height: 31px;
      display: flex;
      align-items: center;
      color: #606060;
  }
  
  #period2{
      font-family: KoPubWorldDotum;
      font-style: normal;
      font-weight: 500;
      font-size: 20px;
      line-height: 31px;
      display: flex;
      align-items: center;
      color: #606060;
  }`,`div class="커리큘럼">
    <span id="curriculum">CURRICULUM</span>
    <span id="curriculumtxt">Target</span>
    <span id="curriculumtxt2">Checklist</span>
    <div class="target">
        <img src="../images/beforeclass.png" class="classimage">
        <span class="targettxt">입문자</span>
    </div>
    <div class="checklist">    
        <div class="tt">
            <span class="checkv">V</span>
            <span class="checktxt">스페인어가 처음</span>
        </div>
        <div class="tt">
            <span class="checkv">V</span>
            <span class="checktxt">단기간에 스페인어 기초를 쌓고 싶음</span>
        </div>
        <div class="tt">
            <span class="checkv">V</span>
            <span class="checktxt">A1 수준을 커버하고 싶음</span>
        </div>
    </div>
    <div class="period">  
        <img src="../images/beforeclass.png" class="classimage">
        <span id="period">2-3개월 (주2회, 2h 기준)</span>
    </div>
    <div class="target">    
        <img src="../images/duringclass.png" class="classimage">
        <span class="targettxt">중급자</span>
    </div>
    <div class="checklist">    
        <div class="tt">
            <span class="checkv">V</span>
            <span class="checktxt">제2외국어를 스페인어로 선택함</span>
        </div>
        <div class="tt">
            <span class="checkv">V</span>
            <span class="checktxt">간단한 알파벳과 단어 정도는 알고 있음</span>
        </div>
        <div class="tt">
            <span class="checkv">V</span>
            <span class="checktxt">A2 수준까지 커버하고 싶음</span>
        </div>
    </div>
    <div class="period">  
        <img src="../images/beforeclass.png" class="classimage">
        <span id="period2">3-4개월 (주3회, 2h 기준)</span>
    </div>
    <div class="target">
        <img src="../images/afterclass.png" class="classimage">
        <span class="targettxt">고급자</span>
    </div>
    <div class="checklist">    
        <div class="tt">
            <span class="checkv">V</span>
            <span class="checktxt">일상을 넘어서 비즈니스, 대학 수업까지 커버하고 싶음</span>
        </div>
        <div class="tt">
            <span class="checkv">V</span>
            <span class="checktxt">현지인과 자유롭게 소통하고 싶음</span>
        </div>
        <div class="tt"></div>
            <span class="checkv">V</span>
            <span class="checktxt">문화적 맥락에 맞는 어휘를 사용하고 싶음</span>
        </div>
    </div>`));
});
router.get('/apply', function(request, response){
  response.send(page(`@font-face{
    font-family:"KoPubWorldDotum";
    src:url("./font/KoPubWorld Dotum Medium.ttf") format("truetype");
}
.수강신청{
    position:relative;
    top:104px;
    display:grid;
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: auto;
    align-items: center;
    text-align: center;
    max-width: 1440px;
    margin-left:auto;
    margin-right:auto;
    font-family: KoPubWorldDotum;
    font-style: normal;
    font-weight: 500;
    font-size: 24px;
    line-height: 46px;
    row-gap: 15px;
}
@media screen and (max-width:800px){
    .수강신청{
        grid-template-columns: repeat(1, 1fr);
    }
}
.테스트{
    margin-left:auto;
    margin-right:auto;
    display: flex;
    width: 80%;
    flex-direction: column;
    height: 100%;
    background: #FFFFFF;
    
    border: 0.5px solid #BDBDBD;
    box-sizing: border-box;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
}
.level{
    position: relative;
    width:15%;
    left:10%;
    bottom: -10%;
}
.txt1{
    position: relative;
    left: -15%;
    bottom: -10%;
}
.txt2{
    position: relative;
    left: -24%;
    bottom: -10%;
}
.txt3{
    position: relative;
    bottom: -40%;
}
.레벨{
    margin-left:auto;
    margin-right:auto;
    width: 80%;
    display: flex;
    flex-direction: column;
    background: #FFFFFF;
    
    border: 0.5px solid #BDBDBD;
    box-sizing: border-box;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
}
.box{
    display:flex;
    width: 80%;
    margin-left:auto;
    margin-right:auto;
    margin-bottom: 20px;
    justify-content: space-around;
    background: #FFFFFF;

    border: 0.5px solid #BDBDBD;
    box-sizing: border-box;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
    border-radius: 100px;
}
.img{
    margin:5%;
    width: 20%;

}
.tptext{
    margin-top: 10px;
    margin-bottom: 10px;
    font-style: bold;
    z-index:1;
}

.txt4{
    margin-top:auto;
    margin-bottom: auto;
    font-size: 20px;
    position:relative;
    left:-8%;
    margin-left: 5px;
}
.txt5{
    margin-top:auto;
    margin-bottom: auto;
    font-size: 18px;
    position: relative;
    right: -10%;
}
.arrow{
    width:10%;
    margin-left: 5%;
    margin-top:auto;
    margin-bottom: auto;
}
`,
  `<div class="수강신청">
  <div class="테스트">
      <span class="tptext">레벨테스트</span>
      <img src="../images/leveltest.png" class="level">
      <span class="txt1">나는 어떤 수업을 들어야 될까?</span>
      <span class="txt2">약 n분 소요됩니다.</span>
      <span class="txt3">알아보기</span>
  </div> 
  <div class="레벨"> 
      <span class="tptext">이미 알고 있어요!</span> 
      <div class="box">
          <img src="../images/basic.png" class="img">
          <div class="txt4">입문반</div>
          <div class="txt5">신청하기</div>
          <img src="../images/arrow.png" class="arrow">
      </div>
      <div class="box">
          <img src="../images/intermediate.png" class="img">
          <div class="txt4">중급반</div>
          <div class="txt5">신청하기</div>
          <img src="../images/arrow.png" class="arrow">
      </div>
      <div class="box">
          <img src="../images/master.png" class="img">
          <div class="txt4">고급반</div>
          <div class="txt5">신청하기</div>
          <img src="../images/arrow.png" class="arrow">
      </div>
  </div>     
</div>`

  ));
});
router.get('/review', function(request, response){
  response.send(page(`.review{position:relative; top:104px;}`,`<div class="review">review</div>`
  ));
});
router.get('/notice', function(request, response){
  response.send(page(`.notice{position:relative; top:104px;}`,`<div class="notice">notice</div>`
  ));
});
router.get('/login', function(request, response){
  response.send(page(`.log{position:relative; top:104px;}`,`<div class="log">
  <img src="../images/logo.png" class="logo">
  <span>로그인</span>
  <div class="leftside">
      <form method="post">
          <input type="text" name="id" placeholder="아이디">
          <input type="password" name="title" placeholder="비밀번호">
          <input type="submit" value="로그인">
      </form>
      <span>아이디 혹은 비밀번호가 기억나지 않는다면?</span>
      <button type="button">아이디/비밀번호 찾기</button> 
  </div>
  <div class="rightside">
      <div>아직 회원이 아니라면</div>
      <button type="button">회원가입</button>
  </div>
</div>`
  ));
});
router.get('/signin', function(request, response){
  response.send(page(`.signin{position:relative; top:104px;}`,`<div class="signin">signin</div>`
  ));
});
router.get('/IDPW', function(request, response){
  response.send(page(`.IDPW{position:relative; top:104px;}`,`<div class="IDPW">IDPW</div>`
  ));
});
router.get('/myroom', function(request, response){
  response.send(page(`.myroom{position:relative; top:104px;}`,`<div class="myroom">myroom</div>`
  ));
});
  module.exports = router;